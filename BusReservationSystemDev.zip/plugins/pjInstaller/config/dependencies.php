<?php
return array(
    'validate' => '>=1.15.1',
	'jquery' => '>=3.1.1',
    'jquery_ui' => '>=1.12.1',
    'steps' => '>=1.1.0',
);
?>