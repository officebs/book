<div id="frmStep6" class="wizard-big">
    <h2>Requires</h2>

    <fieldset></fieldset>

    <h2>MySQL Details</h2>

    <fieldset></fieldset>

    <h2>Install Paths</h2>

    <fieldset></fieldset>

    <h2>Admin Login</h2>

    <fieldset></fieldset>

    <h2>Install Progress</h2>

    <fieldset></fieldset>

    <h2>Finish</h2>

    <fieldset>
        <h2>Installation Successful!</h2>

        <p>You can login product administration page <a href="<?php echo $_SERVER['PHP_SELF']; ?>?controller=pjBase&amp;action=pjActionLogin">here</a>.</p>
    </fieldset>
</div>